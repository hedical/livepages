// ─── Définition de tous les extracts disponibles ───────────────────────────
// Pour ajouter un extract :
//   1. Ajouter ici
//   2. Ajouter un case dans background/service-worker.js → runExtract()
const EXTRACTS = [
  {
    id: 'ventilation-ms',
    name: 'CD - Ventilation MS ventilée par analytique',
    desc: 'Paie > États > États d\'analyse > Gestion avancée',
    outputFile: 'Ventilation_MS_analytique'
  }
  // Ajouter d'autres extracts ici
];

// ─── État global ─────────────────────────────────────────────────────────────
let extractionRunning = false;
// ─── Init ─────────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  buildExtractList();
  buildYearSelector();
  setupPeriodToggle();
  setupButtons();
  await checkCurrentTab();

  // Écouter les messages du content script / service worker
  chrome.runtime.onMessage.addListener(handleBackgroundMessage);
});

// ─── Construction de la liste des extracts ────────────────────────────────────
function buildExtractList() {
  const list = document.getElementById('extract-list');
  list.innerHTML = '';

  EXTRACTS.forEach(ext => {
    const item = document.createElement('div');
    item.className = 'extract-item selected';
    item.dataset.id = ext.id;

    item.innerHTML = `
      <input type="checkbox" id="chk-${ext.id}" checked>
      <div class="extract-info">
        <div class="extract-name">${ext.name}</div>
        <div class="extract-desc">${ext.desc}</div>
      </div>
    `;

    item.addEventListener('click', (e) => {
      if (e.target.tagName === 'INPUT') return;
      const chk = item.querySelector('input');
      chk.checked = !chk.checked;
      item.classList.toggle('selected', chk.checked);
    });

    item.querySelector('input').addEventListener('change', (e) => {
      item.classList.toggle('selected', e.target.checked);
    });

    list.appendChild(item);
  });
}

// ─── Sélecteur d'années ───────────────────────────────────────────────────────
function buildYearSelector() {
  const sel = document.getElementById('period-year');
  const currentYear = new Date().getFullYear();
  for (let y = currentYear; y >= currentYear - 5; y--) {
    const opt = document.createElement('option');
    opt.value = y;
    opt.textContent = y;
    sel.appendChild(opt);
  }
}

// ─── Toggle période personnalisée ─────────────────────────────────────────────
function setupPeriodToggle() {
  document.querySelectorAll('input[name="period"]').forEach(radio => {
    radio.addEventListener('change', () => {
      const custom = document.getElementById('custom-period');
      custom.classList.toggle('hidden', radio.value !== 'custom');
    });
  });
}

// ─── Boutons ──────────────────────────────────────────────────────────────────
function setupButtons() {
  document.getElementById('btn-go-to-nibelis').addEventListener('click', () => {
    chrome.tabs.create({ url: 'https://client.nibelis.com/servlet/Gestion?CONVERSATION=HomeAccueilGeneral&ACTION=MODI&MAJ=N' });
    window.close();
  });

  document.getElementById('btn-select-all').addEventListener('click', () => {
    document.querySelectorAll('.extract-item').forEach(item => {
      item.querySelector('input').checked = true;
      item.classList.add('selected');
    });
  });

  document.getElementById('btn-deselect-all').addEventListener('click', () => {
    document.querySelectorAll('.extract-item').forEach(item => {
      item.querySelector('input').checked = false;
      item.classList.remove('selected');
    });
  });

  document.getElementById('btn-start').addEventListener('click', startExtraction);

  document.getElementById('btn-cancel').addEventListener('click', cancelExtraction);

  document.getElementById('btn-restart').addEventListener('click', () => {
    showScreen('screen-select');
  });

  document.getElementById('btn-retry').addEventListener('click', () => {
    showScreen('screen-select');
  });
}

// ─── Vérification de l'onglet courant ─────────────────────────────────────────
async function checkCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.url || !tab.url.includes('client.nibelis.com')) {
    showScreen('screen-wrong-page');
  } else {
    showScreen('screen-select');
  }
}

// ─── Démarrer l'extraction ─────────────────────────────────────────────────────
async function startExtraction() {
  const selected = getSelectedExtracts();
  if (selected.length === 0) {
    alert('Veuillez sélectionner au moins un extract.');
    return;
  }

const period = getPeriodConfig();

  showScreen('screen-progress');
  updateProgress(0, 'Démarrage...', '');
  addLog('Extraction démarrée pour ' + selected.length + ' rapport(s)');

  extractionRunning = true;

  // Récupérer l'onglet actif
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  // Envoyer la commande au service worker
  chrome.runtime.sendMessage({
    type: 'START_EXTRACTION',
    tabId: tab.id,
    extracts: selected,
    period: period
  });
}

// ─── Annuler ──────────────────────────────────────────────────────────────────
function cancelExtraction() {
  chrome.runtime.sendMessage({ type: 'CANCEL_EXTRACTION' });
  extractionRunning = false;
  showScreen('screen-select');
}

// ─── Récupérer les extracts sélectionnés ──────────────────────────────────────
function getSelectedExtracts() {
  const selected = [];
  document.querySelectorAll('.extract-item').forEach(item => {
    if (item.querySelector('input').checked) {
      const id = item.dataset.id;
      const ext = EXTRACTS.find(e => e.id === id);
      if (ext) selected.push(ext);
    }
  });
  return selected;
}

// ─── Récupérer la configuration de période ────────────────────────────────────
function getPeriodConfig() {
  const mode = document.querySelector('input[name="period"]:checked').value;
  if (mode === 'last-closed') {
    return { mode: 'last-closed' };
  }
  return {
    mode: 'custom',
    month: document.getElementById('period-month').value,
    year: document.getElementById('period-year').value
  };
}

// ─── Traitement des messages du background ────────────────────────────────────
function handleBackgroundMessage(msg) {
  switch (msg.type) {
    case 'PROGRESS':
      updateProgress(msg.percent, msg.step, msg.extract);
      break;

    case 'LOG':
      addLog(msg.text, msg.level);
      break;

    case 'DONE':
      onExtractionDone(msg.files);
      break;

    case 'ERROR':
      onExtractionError(msg.message);
      break;
  }
}

// ─── Mise à jour de la barre de progression ───────────────────────────────────
function updateProgress(percent, stepLabel, extractLabel) {
  document.getElementById('progress-bar').style.width = percent + '%';
  document.getElementById('progress-percent').textContent = Math.round(percent) + '%';
  if (stepLabel) document.getElementById('progress-step-label').textContent = stepLabel;
  if (extractLabel !== undefined) document.getElementById('progress-extract-label').textContent = extractLabel;
}

// ─── Ajouter une ligne de log ─────────────────────────────────────────────────
function addLog(text, level = 'info') {
  const container = document.getElementById('log-container');
  const entry = document.createElement('div');
  entry.className = 'log-entry log-' + level;
  const time = new Date().toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  entry.textContent = '[' + time + '] ' + text;
  container.appendChild(entry);
  container.scrollTop = container.scrollHeight;
}

// ─── Extraction terminée ──────────────────────────────────────────────────────
function onExtractionDone(files) {
  extractionRunning = false;
  const names = files.map(f => f.name).join(', ');
  document.getElementById('done-message').textContent =
    'Téléchargement lancé : ' + names;
  const doneFiles = document.getElementById('done-files');
  doneFiles.innerHTML = '';
  files.forEach(f => {
    const div = document.createElement('div');
    div.className = 'done-file-item';
    div.textContent = f.name;
    doneFiles.appendChild(div);
  });
  showScreen('screen-done');
}

// ─── Erreur d'extraction ──────────────────────────────────────────────────────
function onExtractionError(message) {
  extractionRunning = false;
  document.getElementById('error-message').textContent = message;
  showScreen('screen-error');
}

// ─── Affichage d'un écran ─────────────────────────────────────────────────────
function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.add('hidden'));
  document.getElementById(id).classList.remove('hidden');
}
