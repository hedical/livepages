// ─── Service Worker Nibelis Extract ──────────────────────────────────────────

let cancelled = false;

// ─── Messages popup ───────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'START_EXTRACTION') {
    cancelled = false;
    runExtractions(msg.tabId, msg.extracts, msg.period)
      .catch(err => broadcast({ type: 'ERROR', message: err.message }));
  }
  if (msg.type === 'CANCEL_EXTRACTION') cancelled = true;
});

// ─── Orchestrateur ────────────────────────────────────────────────────────────
async function runExtractions(tabId, extracts, period) {
  const total = extracts.length;
  const allFiles = [];

  for (let i = 0; i < extracts.length; i++) {
    if (cancelled) { broadcast({ type: 'LOG', text: 'Annulé.', level: 'error' }); return; }

    const ext = extracts[i];
    const progress = (pct, step) => broadcast({
      type: 'PROGRESS',
      percent: (i / total) * 100 + pct / total,
      step, extract: ext.name
    });

    broadcast({ type: 'LOG', text: `▶ ${ext.name}` });
    try {
      const files = await runExtract(tabId, ext, period, progress);
      allFiles.push(...files);
      broadcast({ type: 'LOG', text: `✓ ${ext.name}`, level: 'success' });
    } catch (err) {
      if (cancelled) return;
      broadcast({ type: 'ERROR', message: `"${ext.name}" : ${err.message}` });
      return;
    }
  }

  broadcast({ type: 'PROGRESS', percent: 100, step: 'Terminé !' });
  broadcast({ type: 'DONE', files: allFiles });
}

function runExtract(tabId, extract, period, progress) {
  switch (extract.id) {
    case 'ventilation-ms': return extractVentilationMS(tabId, period, progress);
    default: throw new Error('Extract inconnu : ' + extract.id);
  }
}

// ─── Utilitaires ──────────────────────────────────────────────────────────────
const sleep = ms => new Promise(r => setTimeout(r, ms));
const broadcast = msg => chrome.runtime.sendMessage(msg).catch(() => {});

function exec(tabId, step, params = {}) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, { type: 'EXECUTE_STEP', step, params }, res => {
      if (chrome.runtime.lastError) return reject(new Error(chrome.runtime.lastError.message));
      if (!res) return reject(new Error('Pas de réponse du content script'));
      if (!res.success) return reject(new Error(res.error));
      resolve(res.result);
    });
  });
}

// Exécute une fonction JS dans le monde principal de la page (pas le monde isolé du content script)
async function callPageFn(tabId, fnName) {
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func: (name) => {
      const parts = name.split('.');
      let obj = window;
      for (let i = 0; i < parts.length - 1; i++) {
        obj = obj[parts[i]];
        if (!obj) return { error: `Objet introuvable : ${parts.slice(0, i + 1).join('.')}` };
      }
      const fn = obj[parts[parts.length - 1]];
      if (typeof fn !== 'function') {
        const avail = Object.getOwnPropertyNames(window)
          .filter(k => { try { return typeof window[k] === 'function'; } catch (e) { return false; } })
          .slice(0, 30).join(', ');
        return { error: `Fonction introuvable : ${name}. Fonctions window dispo : ${avail}` };
      }
      try {
        fn.call(obj);
        return { success: true };
      } catch (e) {
        return { error: `Erreur lors de l'appel ${name} : ${e.message}` };
      }
    },
    args: [fnName]
  });
  const res = results?.[0]?.result;
  if (res?.error) throw new Error(res.error);
  return res;
}

function waitForTabLoad(tabId, timeout = 30000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error('Timeout chargement page'));
    }, timeout);
    const listener = (id, info) => {
      if (id === tabId && info.status === 'complete') {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });
}

function waitForTabUrl(tabId, pattern, timeout = 20000) {
  const start = Date.now();
  return new Promise((resolve, reject) => {
    const check = async () => {
      const tab = await chrome.tabs.get(tabId);
      if (tab.url?.includes(pattern)) return resolve(tab.url);
      if (Date.now() - start > timeout) return reject(new Error('Timeout URL: ' + pattern));
      setTimeout(check, 400);
    };
    check();
  });
}

// Fetch le fichier XLS avec retries jusqu'à ce que la génération soit prête
// Retourne { buffer, filename } — filename extrait de Content-Disposition (ou null)
async function fetchXlsWithRetry(xlsUrl, maxAttempts = 20, delayMs = 5000) {
  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    broadcast({ type: 'LOG', text: `Tentative téléchargement ${attempt}/${maxAttempts}...` });
    const res = await fetch(xlsUrl, { credentials: 'include' });
    if (res.ok) {
      const buffer = await res.arrayBuffer();
      // Si la réponse est vide ou trop petite, le rapport n'est pas encore prêt
      if (buffer.byteLength < 500) {
        broadcast({ type: 'LOG', text: `Réponse trop petite (${buffer.byteLength} octets), rapport pas encore prêt, attente...` });
        await sleep(delayMs);
        continue;
      }
      // Extraire le nom de fichier depuis Content-Disposition
      let filename = null;
      const disposition = res.headers.get('Content-Disposition');
      if (disposition) {
        const m = disposition.match(/filename[^;=\n]*=["']?([^"';\n]+)["']?/i);
        if (m) filename = decodeURIComponent(m[1].trim());
      }
      broadcast({ type: 'LOG', text: `[DEBUG] Content-Disposition: ${disposition}`, level: 'info' });
      return { buffer, filename };
    }
    if (res.status === 503 || res.status === 202) {
      broadcast({ type: 'LOG', text: `Rapport en cours de génération (${res.status}), attente...` });
      await sleep(delayMs);
    } else {
      throw new Error(`Erreur serveur : HTTP ${res.status}`);
    }
  }
  throw new Error('Timeout : le rapport n\'a pas été généré dans les temps');
}


// Attend que la génération Nibelis soit terminée en surveillant le texte de la page
// Nibelis affiche "prise en compte" pendant la génération, puis met à jour la page via AJAX.
async function pollForGenerationComplete(tabId, timeout = 180000) {
  const start = Date.now();
  await sleep(2000); // Laisser generer() démarrer

  let seenWaiting = false;
  let lastLog = 0;

  while (Date.now() - start < timeout) {
    try {
      const [result] = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        func: () => (document.body?.innerText || '').toLowerCase()
      });
      const text = result?.result || '';

      const isWaiting = text.includes('prise en compte')
                     || text.includes('en cours de générat')
                     || text.includes('traitement en cours')
                     || text.includes('génération en cours')
                     || text.includes('demande en cours');

      if (isWaiting) {
        seenWaiting = true;
        if (Date.now() - lastLog > 9000) {
          broadcast({ type: 'LOG', text: 'Génération en cours sur le serveur...' });
          lastLog = Date.now();
        }
      } else if (seenWaiting) {
        // Message d'attente était là, maintenant disparu → génération terminée
        broadcast({ type: 'LOG', text: "Signal de fin détecté (message d'attente disparu).", level: 'success' });
        return;
      } else if (Date.now() - start > 15000) {
        // Après 15s sans voir le message d'attente, on considère que c'est terminé
        broadcast({ type: 'LOG', text: "Pas de message d'attente détecté, poursuite...", level: 'info' });
        return;
      }
    } catch (e) {
      // Page en transition, continuer
    }
    await sleep(3000);
  }

  // Timeout - on essaie quand même
  broadcast({ type: 'LOG', text: 'Timeout poll génération, tentative de téléchargement...', level: 'info' });
}

// Attend que Nibelis affiche la confirmation "prise en compte" après generer()
async function waitForPriseEnCompte(tabId, timeout = 30000) {
  const start = Date.now();
  while (Date.now() - start < timeout) {
    try {
      const [result] = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        func: () => (document.body?.innerText || '').toLowerCase()
      });
      if ((result?.result || '').includes('prise en compte')) return;
    } catch (e) {}
    await sleep(500);
  }
  throw new Error('Timeout : confirmation "prise en compte" non détectée');
}

// Attend que la page ListeEtats affiche les données (après rafraîchissement AJAX ou second chargement)
async function waitForListeEtatsData(tabId, timeout = 60000) {
  const start = Date.now();
  let lastLog = 0;

  while (Date.now() - start < timeout) {
    try {
      const [result] = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        func: () => ({
          text: (document.body?.innerText || '').toLowerCase(),
          readyState: document.readyState
        })
      });
      const { text, readyState } = result?.result || {};

      if (readyState === 'complete' && text && text.includes('(100%)')) {
        broadcast({ type: 'LOG', text: "État d'avancement 100% détecté.", level: 'success' });
        return;
      }
    } catch (e) {
      // page en transition
    }

    if (Date.now() - lastLog > 5000) {
      broadcast({ type: 'LOG', text: 'Attente du rafraîchissement des résultats...' });
      lastLog = Date.now();
    }
    await sleep(2000);
  }

  broadcast({ type: 'LOG', text: 'Timeout rafraîchissement, tentative de téléchargement...', level: 'info' });
}

// ─── Extract : CD - Ventilation MS ventilée par analytique ───────────────────
async function extractVentilationMS(tabId, period, progress) {
  const log = (text, level = 'info') => broadcast({ type: 'LOG', text, level });

  // ── 1. Obtenir ID_PARA (cache ou découverte) ───────────────────────────────
  progress(5, 'Initialisation...');

  const stored = await chrome.storage.local.get(['ventilation_ms_idPara', 'ventilation_ms_modelUrl']);
  let idPara = stored.ventilation_ms_idPara;
  let modelUrl = stored.ventilation_ms_modelUrl;

  if (!idPara) {
    // Première utilisation : naviguer pour découvrir ID_PARA
    log('Première utilisation : découverte de ID_PARA...');

    await chrome.tabs.update(tabId, {
      url: 'https://client.nibelis.com/servlet/GestionParaEdit?ACTION=MODI&MAJ=N&ETAT=ListeGestionAvancee'
    });
    await waitForTabLoad(tabId);
    await sleep(2000);

    // Lire l'état actuel du sélecteur de modèle
    const selectInfo = await exec(tabId, 'READ_SELECT', { selector: 'select[name="SELE_ID_LIST"]' });
    log(`Modèle actuel dans la page : "${selectInfo.text}" (val=${selectInfo.value})`, 'info');

    if (selectInfo.value === '182273') {
      // Déjà sur ce modèle → basculer vers un autre pour forcer la navigation
      // (le changement de valeur identique ne déclenche pas de navigation Nibelis)
      const other = selectInfo.options.find(o => o.value && o.value !== '182273');
      if (other) {
        log(`Basculement temporaire vers "${other.text}"...`);
        await exec(tabId, 'SET_SELECT', { selector: 'select[name="SELE_ID_LIST"]', value: other.value });
        // Attendre que la page de l'autre modèle se charge (le content script sera récréé)
        await waitForTabLoad(tabId);
        await sleep(1500);
      }
    }

    // Maintenant sélectionner 182273 (la valeur est garantie différente)
    progress(15, 'Sélection du rapport...');
    log('Sélection : CD - Ventilation MS ventilée par analytique');
    await exec(tabId, 'SET_SELECT', { selector: 'select[name="SELE_ID_LIST"]', value: '182273' });

    const discoveredUrl = await waitForTabUrl(tabId, 'ID_LIST=182273', 15000);
    log(`[DEBUG] URL découverte : ${discoveredUrl}`, 'info');

    idPara = new URL(discoveredUrl).searchParams.get('ID_PARA') || new URL(discoveredUrl).searchParams.get('ID');
    if (!idPara) throw new Error('Impossible de récupérer ID_PARA depuis l\'URL');

    // Construire l'URL de navigation directe (pour les prochains runs)
    modelUrl = discoveredUrl; // URL telle que Nibelis l'a fournie

    await chrome.storage.local.set({ ventilation_ms_idPara: idPara, ventilation_ms_modelUrl: modelUrl });
    log(`ID_PARA découvert et mis en cache : ${idPara}`, 'success');
  } else {
    log(`ID_PARA (cache) : ${idPara}`, 'info');
  }

  // ── 2. Navigation directe vers la page du modèle ──────────────────────────
  // Equivalent d'un "refresh" manuel sur la page → generer() disponible
  progress(22, 'Chargement du rapport...');
  log(`[DEBUG] Navigation : ${modelUrl}`, 'info');
  await chrome.tabs.update(tabId, { url: modelUrl });
  await waitForTabLoad(tabId);
  await sleep(2500);

  // ── 3. Sélectionner la période (dans le monde principal pour que Nibelis JS la voit) ────
  progress(28, 'Sélection de la période...');

  // D'abord, logger toutes les options disponibles pour diagnostic
  const [optionsResult] = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func: () => {
      const el = document.querySelector('select[name="PERIODES"]');
      if (!el) return null;
      return Array.from(el.options).map((o, i) => ({ i, value: o.value, text: o.text }));
    }
  });
  log(`[DEBUG] Options PERIODES : ${JSON.stringify(optionsResult?.result?.slice(0, 5))}`, 'info');

  // Sélectionner la période depuis le monde principal
  const [periodeExec] = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func: (mode, targetIndex, targetValue) => {
      const el = document.querySelector('select[name="PERIODES"]');
      if (!el) return { error: 'select[name="PERIODES"] introuvable' };
      if (mode === 'last-closed') {
        el.selectedIndex = targetIndex;
      } else {
        el.value = targetValue;
      }
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return {
        value: el.value,
        text: el.options[el.selectedIndex]?.text,
        selectedIndex: el.selectedIndex
      };
    },
    args: [period.mode, 2, `01/${period.month}/${period.year}`]
  });

  const periodeInfo = periodeExec?.result;
  if (periodeInfo?.error) throw new Error(periodeInfo.error);
  log(`Période : ${periodeInfo.text} (idx=${periodeInfo.selectedIndex}, val=${periodeInfo.value})`, 'success');
  const periodText = periodeInfo.text;
  await sleep(1000); // laisser le temps à Nibelis de traiter le changement

  // ── 4. Générer + clic sur "Afficher le détail"
  progress(42, 'Lancement de la génération...');
  await callPageFn(tabId, 'generer');
  log('Génération lancée.', 'success');

  // Attendre la confirmation Nibelis avant de cliquer Afficher
  progress(50, 'Attente de la confirmation...');
  await waitForPriseEnCompte(tabId, 30000);
  log('Demande prise en compte.', 'success');

  // ── 5. Appel de Liste.html() = clic sur "Afficher" (href="javascript:Liste.html()")
  progress(60, 'Ouverture des résultats...');
  log('Appel Liste.html()...');
  await callPageFn(tabId, 'Liste.html');
  await waitForTabLoad(tabId, 30000);
  log('Page résultats chargée, attente du rafraîchissement...', 'info');

  // ── 5b. Attendre que la page se rafraîchisse avec les données
  progress(75, 'Attente des données...');
  await waitForListeEtatsData(tabId, 60000);
  log('Données prêtes.', 'success');

  // ── 6. Télécharger le XLSX via chrome.downloads
  const periodLabel = periodText.replace(/\s+/g, '_');
  const filename = 'Ventilation_MS_analytique_' + periodLabel + '.xlsx';

  const xlsUrl = 'https://client.nibelis.com/servlet/ListeEtats'
    + '?TEMPLATE=ListeGestionAvancee'
    + '&ETAT=ListeGestionAvancee'
    + '&SAUV=ListeGestionAvancee'
    + '&ID_LIST=182273'
    + '&ID_PARA=' + idPara
    + '&XLS=POI'
    + '&up=' + Math.random();

  progress(90, 'Téléchargement...');
  log('Lancement du téléchargement : ' + filename);
  await chrome.downloads.download({ url: xlsUrl, filename, saveAs: false });
  log('Téléchargement lancé : ' + filename, 'success');
  return [{ name: filename }];
}
