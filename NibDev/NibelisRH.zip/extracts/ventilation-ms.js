// ─── Définition de l'extract : CD - Ventilation MS ventilée par analytique ───
//
// Ce fichier documente le chemin de navigation et les sélecteurs CSS utilisés.
// Si Nibelis change son interface, mettez à jour les sélecteurs ici.
//
// Chemin de navigation :
//   Menu latéral gauche
//   └─ Paie
//      └─ Etats
//         └─ Etats d'analyse
//            └─ Gestion avancée
//               └─ CD - Ventilation MS ventilée par analytique
//
// Actions :
//   1. Sélectionner la période (dernier mois clôturé ou personnalisée)
//   2. Cliquer "Générer"
//   3. Cliquer "Afficher"
//   4. Attendre la génération
//   5. Télécharger le fichier "Détail" au format XLS
//
// ─────────────────────────────────────────────────────────────────────────────

export const VENTILATION_MS_CONFIG = {
  id: 'ventilation-ms',
  name: 'CD - Ventilation MS ventilée par analytique',
  desc: "Paie > Etats > Etats d'analyse > Gestion avancée",
  outputFile: 'Ventilation_MS_analytique',

  // Sélecteurs CSS à ajuster selon l'inspection réelle de la page
  selectors: {
    // Sélecteur du <select> de période (à confirmer par inspection)
    periodSelect: 'select[name*="periode"], select[name*="PERIODE"], select[name*="mois"]',

    // Bouton "Générer"
    btnGenerer: null, // cherché par texte si null

    // Bouton "Afficher"
    btnAfficher: null, // cherché par texte si null

    // Lien/bouton "Détail" pour le téléchargement XLS
    btnDetail: null, // cherché par texte si null

    // Spinner ou indicateur de chargement (pour attendre la fin)
    spinner: null, // ex: '.loading-spinner', '#progress-indicator'

    // Texte indiquant la fin de génération
    doneText: 'Détail'
  },

  // Timeouts (en ms)
  timeouts: {
    navigation: 30000,
    menuClick: 10000,
    reportSelect: 15000,
    generation: 600000  // 10 minutes max
  }
};
