// ─── Content Script Nibelis Extract ──────────────────────────────────────────
// Exécuté sur client.nibelis.com — reçoit des commandes du service worker

(function () {
  'use strict';

  // ─── Utilitaires ─────────────────────────────────────────────────────────────

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  function waitForText(text, timeout = 60000) {
    const start = Date.now();
    return new Promise((resolve, reject) => {
      const check = () => {
        if (document.body.innerText.includes(text)) return resolve(true);
        if (Date.now() - start > timeout) return reject(new Error(`Timeout texte : "${text}"`));
        setTimeout(check, 500);
      };
      check();
    });
  }

  function waitForElement(selector, timeout = 15000) {
    const start = Date.now();
    return new Promise((resolve, reject) => {
      const check = () => {
        const el = document.querySelector(selector);
        if (el) return resolve(el);
        if (Date.now() - start > timeout) return reject(new Error(`Timeout élément : "${selector}"`));
        setTimeout(check, 300);
      };
      check();
    });
  }

  // ─── Écoute des commandes ────────────────────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type !== 'EXECUTE_STEP') return;

    executeStep(msg.step, msg.params)
      .then(result => sendResponse({ success: true, result }))
      .catch(err => sendResponse({ success: false, error: err.message }));

    return true; // async
  });

  // ─── Exécution des étapes ────────────────────────────────────────────────────
  async function executeStep(step, params = {}) {

    // Définir la valeur d'un <select> et déclencher change
    if (step === 'SET_SELECT') {
      const el = await waitForElement(params.selector, params.timeout || 15000);
      // Si forceChange et la valeur est déjà celle voulue, on passe d'abord par une autre option
      // pour forcer un vrai événement change (sinon Nibelis ne navigue pas)
      if (params.forceChange && el.value === String(params.value)) {
        const other = Array.from(el.options).find(o => o.value && o.value !== String(params.value));
        if (other) {
          el.value = other.value;
          el.dispatchEvent(new Event('change', { bubbles: true }));
          await sleep(1000);
        }
      }
      el.value = params.value;
      if (!params.silent) {
        el.dispatchEvent(new Event('change', { bubbles: true }));
        await sleep(300);
      }
      return { value: el.value, text: el.options[el.selectedIndex]?.text };
    }

    // Sélectionner par index dans un <select>
    if (step === 'SET_SELECT_INDEX') {
      const el = await waitForElement(params.selector, params.timeout || 15000);
      el.selectedIndex = params.index;
      if (!params.silent) {
        el.dispatchEvent(new Event('change', { bubbles: true }));
        await sleep(300);
      }
      return { value: el.value, text: el.options[el.selectedIndex]?.text };
    }

    // Appeler une fonction JS de la page (ex: generer, Liste.html, Liste.xlsx)
    if (step === 'CALL_JS') {
      // Résoudre les noms avec points : "Liste.html" → Liste["html"]()
      const parts = params.fn.split('.');
      let obj = window;
      for (let i = 0; i < parts.length - 1; i++) {
        obj = obj[parts[i]];
        if (!obj) throw new Error(`Objet JS introuvable : ${parts.slice(0, i+1).join('.')}`);
      }
      const fn = obj[parts[parts.length - 1]];
      if (typeof fn !== 'function') throw new Error(`Fonction JS introuvable : ${params.fn}`);
      fn.call(obj);
      return { called: params.fn };
    }

    // Attendre qu'un texte apparaisse dans la page
    if (step === 'WAIT_TEXT') {
      await waitForText(params.text, params.timeout || 60000);
      return { found: true };
    }

    // Cliquer sur un élément par sélecteur
    if (step === 'CLICK') {
      const el = await waitForElement(params.selector, params.timeout || 15000);
      el.click();
      await sleep(params.delay || 500);
      return {};
    }

    // Lire la valeur et les options d'un <select>
    if (step === 'READ_SELECT') {
      const el = await waitForElement(params.selector, params.timeout || 15000);
      return {
        value: el.value,
        text: el.options[el.selectedIndex]?.text,
        options: Array.from(el.options).map(o => ({ value: o.value, text: o.text }))
      };
    }

    // Ping
    if (step === 'PING') {
      return { alive: true };
    }

    throw new Error('Étape inconnue : ' + step);
  }

  // Signaler que le content script est prêt
  chrome.runtime.sendMessage({ type: 'CONTENT_READY' }).catch(() => {});

})();
